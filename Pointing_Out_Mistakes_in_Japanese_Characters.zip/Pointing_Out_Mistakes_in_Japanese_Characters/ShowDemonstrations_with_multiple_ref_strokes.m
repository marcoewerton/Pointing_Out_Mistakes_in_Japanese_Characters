% show recorded trajectories

clear variables;
close all;
clc;

% let the user select which demonstration he wants to learn
demonstration_name = input('Please Enter the name of the demonstration you want to see!: ','s');

file_struct = load(['preprocessed_demonstrations/preprocessed_demonstration_' demonstration_name '.mat']);
preprocessed_demonstrations = file_struct.preprocessed_demonstrations;
n_demonstrations = size(preprocessed_demonstrations{1,1},1);

n_strokes = size(preprocessed_demonstrations,2);

for ref_stroke = 1:n_strokes
    figure(ref_stroke);
    hold all;
    for i = 1:n_demonstrations
        for j = 1:n_strokes
            subTrajectory = preprocessed_demonstrations{1,ref_stroke}{i,j};
            plot(subTrajectory(:,1), subTrajectory(:,2), '-b', 'LineWidth', 2);
        end
        pause
    end
end