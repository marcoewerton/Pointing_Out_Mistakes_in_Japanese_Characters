function [ weights ] = linearRidgeRegression( data, feature_matrix, lambda )

weights = (feature_matrix*feature_matrix' + lambda*eye(size(feature_matrix*feature_matrix',1)))\feature_matrix*data;

end

