function [ feature_matrix ] = gaussianBasisFunction( T, N )
    % GAUSSIAN_BASIS_FUNCTION  
    % T: number of timesteps
    % N: number of basis functions
    
    h = T;
    
    %% Define generic basis function
    feature = @(n,t) exp(-0.5*(t-(n-1)*T/(N-1))^2/h);
    
    %% Define PSIs_matrix
    feature_matrix = NaN(T,N);
    
    for n = 1:N
        for t = 1:T
            feature_matrix(t,n) = feature(n,t);
        end
    end
    
    % normalize
    feature_matrix = bsxfun(@rdivide, feature_matrix, sum(feature_matrix,2));

end

