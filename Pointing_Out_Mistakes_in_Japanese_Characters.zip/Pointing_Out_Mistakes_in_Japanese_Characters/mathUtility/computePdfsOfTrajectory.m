function [ probabilities ] = computePdfsOfTrajectory(trajectory_2D, mean_trajectory_2D, covariance_trajectory, T, n_strokes)
%COMPUTEPROBABILITYOFTRAJECTORY takes a 2D trajectory, computes the
%probability at each timestep and returns the corresponding vector
    n_steps = T*n_strokes;
    probabilities = zeros(n_steps,1);
    for i = 1:n_strokes
       for j = 1:T
           %define datapoint X, mu and sigma
           index2D = T*(i-1)+j;
           X = trajectory_2D(index2D,:);
           mu = mean_trajectory_2D(index2D,:);
           index1D = 2*T*(i-1)+j; % because the terms in sigma are organized as [x_Stroke1 y_Stroke1 x_Stroke2 y_Stroke2 x_Stroke3 y_Stroke3 ...] and not as [x x x ... y y y ...]
           cov_matrix_indexes = [index1D index1D+T];
           sigma = NaN(length(cov_matrix_indexes));
           for r = 1:length(cov_matrix_indexes)
               for c = 1:length(cov_matrix_indexes)
                   sigma(r,c) = covariance_trajectory(cov_matrix_indexes(r), cov_matrix_indexes(c));
               end
           end
           probabilities(index2D) = mvnpdf(X,mu,sigma);
       end
    end
    
end

