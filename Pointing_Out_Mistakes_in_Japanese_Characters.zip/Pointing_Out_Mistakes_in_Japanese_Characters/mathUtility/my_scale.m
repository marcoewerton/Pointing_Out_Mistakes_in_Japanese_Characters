function [ scaled_value ] = my_scale(min_value, max_value, value)
    scaled_value = (value-min_value)/(max_value-min_value);
end

