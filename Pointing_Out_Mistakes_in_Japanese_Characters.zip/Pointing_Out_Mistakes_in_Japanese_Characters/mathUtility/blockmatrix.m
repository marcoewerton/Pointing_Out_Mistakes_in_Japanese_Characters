function [ block_matrix ] = blockmatrix(block, number_of_blocks)
%BLOCKMATRIX    
    % allocate the necessary size
    y_size = size(block,1);
    x_size = size(block,2);
    block_matrix = zeros(y_size*number_of_blocks,x_size*number_of_blocks);
    % iterate over the single blocks diagonally
    for i = 1:number_of_blocks
        block_matrix(1+(y_size*(i-1)):y_size*i,1+(x_size*(i-1)):x_size*i) = block; 
    end

end

