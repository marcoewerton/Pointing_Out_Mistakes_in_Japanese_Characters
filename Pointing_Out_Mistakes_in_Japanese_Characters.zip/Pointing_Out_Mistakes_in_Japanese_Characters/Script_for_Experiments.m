% script for experiments

clear variables;
close all;
clc;

%add utility paths
addpath(genpath('mathUtility'));
addpath(genpath('plotUtility'));
addpath(genpath('utility'));
addpath(genpath('rescale_in_Space'));
addpath(genpath('rescale_in_Time'));

file_struct = load('demonstrations/demonstration_A_with_diff_scales.mat');
trajectories = file_struct.trajectories;
n_demonstrations = size(trajectories,1);

n_strokes = size(trajectories,2);

figure(1);
hold on;
for i = 1:n_demonstrations
   for j = 1:n_strokes
        subTrajectory = trajectories{i,j};
        plot(subTrajectory(:,1), subTrajectory(:,2), 'b-', 'LineWidth', 2);
   end
   %pause;
end

[preprocessed_demonstrations, reference_trajectory_idx] = preprocess_demonstrations( trajectories );

figure(2);
hold on;
for i = 1:n_demonstrations
   for j = 1:n_strokes
        subTrajectory = preprocessed_demonstrations{i,j};
        plot(subTrajectory(:,1), subTrajectory(:,2), 'b-', 'LineWidth', 2);
   end
   %pause;
end

trajectories = preprocessed_demonstrations;
save('demonstrations/preprocessed_demonstration_A_with_diff_scales', 'trajectories');


% Experiment on preprocessing a new trajectory
figure(3);
axis([0 1 0 1]);
hold on;

trajectory = cell(1,n_strokes);
reference_trajectory = cell(1,n_strokes);

for j = 1:n_strokes
    
    h = imfreehand('Closed', false);
    
    % get the position (x,y coordinates) of each point of the curve
    positions = getPosition(h);
    
    trajectory{1,j} = positions;
    
    reference_trajectory{1,j} = preprocessed_demonstrations{reference_trajectory_idx,j};
end

preprocessed_trajectory = preprocess_trajectory( trajectory, reference_trajectory);

figure(2);
hold on;
for j = 1:n_strokes
    subTrajectory = preprocessed_trajectory{1,j};
    plot(subTrajectory(:,1), subTrajectory(:,2), 'r-', 'LineWidth', 2);
end