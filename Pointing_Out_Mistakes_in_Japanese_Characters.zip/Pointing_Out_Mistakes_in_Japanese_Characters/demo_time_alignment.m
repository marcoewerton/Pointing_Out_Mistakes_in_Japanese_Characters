% Script to create figure showing the time alignment
clear variables;
close all;
clc;

%add utility paths
addpath(genpath('mathUtility'));
addpath(genpath('plotUtility'));
addpath(genpath('utility'));
addpath(genpath('rescale_in_Space'));
addpath(genpath('rescale_in_Time'));

load('workspace_after_demo_rescal_repos.mat');

% plot x trajectories of 3rd stroke before time alignment
figure(1);
set_fig_position([0.479 0.428 0.136 0.234]);
hold on;
grid on;
plot(shifted_trajectory1_rescaled{1,3}(:,1), '-b', 'LineWidth', 2);
plot(shifted_trajectory2_rescaled{1,3}(:,1), '-r', 'LineWidth', 2);
xlabel('time step');
ylabel('x trajectory');

% time alignment
time_aligned_trajectory_1 = cell(1,n_strokes);
time_aligned_trajectory_2 = cell(1,n_strokes);
for j = 1:n_strokes
    [time_aligned_trajectory_1{1,j}, time_aligned_trajectory_2{1,j}, upDownPath, cost] = my_dtw( shifted_trajectory1_rescaled{1,j}, shifted_trajectory2_rescaled{1,j} );
end

% plot x trajectories of 3rd stroke after time alignment
figure(2);
set_fig_position([0.479 0.428 0.136 0.234]);
hold on;
grid on;
plot(time_aligned_trajectory_1{1,3}(:,1), '-b', 'LineWidth', 2);
plot(time_aligned_trajectory_2{1,3}(:,1), '-r', 'LineWidth', 2);
xlabel('time step');
ylabel('x trajectory');

save('workspace_after_demo_time_alignment.mat');
