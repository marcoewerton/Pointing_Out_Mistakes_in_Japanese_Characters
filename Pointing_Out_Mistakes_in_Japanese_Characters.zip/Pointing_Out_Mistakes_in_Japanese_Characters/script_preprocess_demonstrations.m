%% Script to preprocess demonstrations and save them
clear variables;
close all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
characters_name = 'KA';
%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(['demonstrations/demonstration_' characters_name '.mat']);

preprocessed_demonstrations = preprocess_demonstrations( trajectories );

save(['preprocessed_demonstrations/preprocessed_demonstration_' characters_name '.mat'], 'preprocessed_demonstrations');