%% Script to add a demonstration to the system
clear variables;
close all;
clc;

%add utility paths
addpath(genpath('mathUtility'));
addpath(genpath('plotUtility'));
addpath(genpath('utility'));
addpath(genpath('rescale_in_Space'));
addpath(genpath('rescale_in_Time'));

% define number of demonstrations
n_demonstrations = 10;

% define name of demonstration
demonstration_name = input('Please enter the name of the demonstration you want to add: ','s');
string = ['demonstrations/demonstration_' demonstration_name '.mat'];
n_strokes = input('Please enter the amount of strokes you need to demonstrate: ');

% alocate cell for trajectories 
trajectories = cell(n_demonstrations, n_strokes);

% record all trajectories
for i = 1:n_demonstrations
    
    close;
    figure(i);
    axis([0 1 0 1]);
    hold on;
   
    for j = 1:n_strokes    
        
        h = imfreehand('Closed', false);
                
        % get the position (x,y coordinates) of each point of the curve
        positions = getPosition(h);
        
        trajectories{i,j} = positions;
    end
    
end

clf;
axis([0 1 0 1]);
hold on;

for i = 1:n_demonstrations
   for j = 1:n_strokes
        plot(trajectories{i,j}(:,1), trajectories{i,j}(:,2), 'r-', 'LineWidth', 2);
   end
end

save(string, 'trajectories');
