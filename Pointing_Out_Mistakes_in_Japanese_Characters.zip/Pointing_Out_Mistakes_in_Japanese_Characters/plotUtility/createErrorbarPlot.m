function [] = createErrorbarPlot( trajectories, input_trajectory_2D, mean_trajectory_2D, cov_trajectory , n_demonstrations, n_strokes, T)
%CREATEERRORBARPLOT takes 2D trajectory for the input and mean trajectory
    % create xline and std
    var = diag(cov_trajectory);
    var_2D = convert1Dto2D(var, n_strokes, T);
    
    for i = 1:n_strokes
        subplot(2,n_strokes,i)
        shadedErrorBar(1:T,mean_trajectory_2D(1+T*(i-1):T*i,1), 2*sqrt(var_2D(1+T*(i-1):T*i,1)));
        hold on;
        plot(1:T,input_trajectory_2D(1+T*(i-1):T*i,1), 'r');
        title(['x ' int2str(i)]);
        xlabel('time step');
        ylabel('x');
        subplot(2,n_strokes,i+n_strokes)
        shadedErrorBar(1:T,mean_trajectory_2D(1+T*(i-1):T*i,2), 2*sqrt(var_2D(1+T*(i-1):T*i,2)));
        hold on;
        plot(1:T,input_trajectory_2D(1+T*(i-1):T*i,2), 'r');
        title(['y ' int2str(i)]);
        xlabel('time step');
        ylabel('y');
    end
    for i = 1:n_demonstrations
        for j = 1:n_strokes
            subTrajectory = trajectories{i,j};
            int_sub_tr = interpl_trajectory(subTrajectory,T);
            subplot(2,n_strokes,j)
            plot(int_sub_tr(:,1), '-', 'Color', [0.7, 0.7, 0.7], 'LineWidth', 2);
            subplot(2,n_strokes,j+n_strokes)
            plot(int_sub_tr(:,2), '-', 'Color', [0.7, 0.7, 0.7], 'LineWidth', 2);
            
        end
    end
    % reforce the mean and the new trajectory
    for i = 1:n_strokes
        subplot(2,n_strokes,i)
        plot(1:T,mean_trajectory_2D(1+T*(i-1):T*i,1), 'LineWidth', 2);
        hold on;
        plot(1:T,input_trajectory_2D(1+T*(i-1):T*i,1), 'r', 'LineWidth', 2);
        subplot(2,n_strokes,i+n_strokes)
        plot(1:T,mean_trajectory_2D(1+T*(i-1):T*i,2), 'LineWidth', 2);
        hold on;
        plot(1:T,input_trajectory_2D(1+T*(i-1):T*i,2), 'r', 'LineWidth', 2);
    end
end

