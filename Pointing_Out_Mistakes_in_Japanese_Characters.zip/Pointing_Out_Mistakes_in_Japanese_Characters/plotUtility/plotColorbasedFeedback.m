function [ values] = plotColorbasedFeedback( trajectory_2D, probabilities, maximum_probabilities, n_strokes, T)

    % define offsets for arctangens
    offset_x = -0.5;
    stretch_x = 15;
    offset_y = 0.5;
    stretch_y = 2;
    max_atan = atan((1+offset_x)*stretch_x);
    n_steps = T*n_strokes;
    values = zeros(n_steps,1);
    % compute values at each timestep
    for i = 1:n_steps
        value = my_scale(0,maximum_probabilities(i),probabilities(i));
        values(i) = atan((value+offset_x)*stretch_x)/(stretch_y*max_atan) + offset_y;
    end
    for stroke = 1:n_strokes
        for t = 1:T
            if t == 1 || t == T
                continue;
            end
            b = min([values(t+T*(stroke-1)) 1.0]);
            r = max([1-values(t+T*(stroke-1)) 0.0]);
            plot(trajectory_2D((T*(stroke-1))+t-1:(T*(stroke-1))+t+1,1),trajectory_2D((T*(stroke-1))+t-1:(T*(stroke-1))+t+1,2),'color',[r 0 b], 'Linewidth', 2);
            if r >= 0.5
                plot(trajectory_2D((T*(stroke-1))+t,1),trajectory_2D((T*(stroke-1))+t,2), 'x', 'color', [r 0 b], 'MarkerSize', 10, 'LineWidth', 2);
            end
        end
    end

end

