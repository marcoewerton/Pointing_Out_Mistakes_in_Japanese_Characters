function [] = plotLineInSegments( line, dt, n_strokes, T, color )
%PLOTLINEINSEGMENTS Takes a 2D vector trajectory and plots it

    for stroke = 1:n_strokes
        for i = 1:T
            plot(line(1+T*(stroke-1):i+T*(stroke-1),1),line(1+T*(stroke-1):i+T*(stroke-1),2), color, 'LineWidth', 2); 
            pause(dt)
        end
    end
    
end

