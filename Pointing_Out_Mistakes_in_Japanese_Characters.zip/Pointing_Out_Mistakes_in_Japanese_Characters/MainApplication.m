%% MainApplication Script
% with this script one can select a demonstration that he/she wants to learn
% and get feedback based on his/her performance!
clear variables;
close all;
clc;

%add utility paths
addpath(genpath('mathUtility'));
addpath(genpath('plotUtility'));
addpath(genpath('utility'));
addpath(genpath('rescale_in_Space'));
addpath(genpath('rescale_in_Time'));

light_gray = [0.7, 0.7, 0.7];

% number of Gaussian basis functions
N = 25;
% regularizer
lambda = 10e-12;

% Gaussian noise
noise = 10e-3;

% axis limitations
ax = [0 1 0 1];

%% USER INPUT SECTION
% let the user select which demonstration he/she wants to learn
demonstration_name = input('Please Enter the name of the demonstration you want to learn!: ','s');

%% LOAD DEMONSTRATION 
file_struct = load(['preprocessed_demonstrations/preprocessed_demonstration_' demonstration_name '.mat']);
preprocessed_demonstrations = file_struct.preprocessed_demonstrations;
n_demonstrations = size(preprocessed_demonstrations{1,1},1);
n_strokes = size(preprocessed_demonstrations,2);

%% variables to store information for each reference stroke
input_trajectory_2D_for_each_ref_stroke = cell(1,n_strokes);
trajectories_after_DTW_with_new_trajectory_for_each_ref_stroke = cell(1,n_strokes);
pdfs_for_each_ref_stroke = cell(1,n_strokes);
maximum_pdfs_for_each_ref_stroke = cell(1,n_strokes);
mean_trajectory_2D_after_DTW_for_each_ref_stroke = cell(1,n_strokes);
cov_trajectory_for_each_ref_stroke = cell(1,n_strokes);

%%
weight_matrix = NaN(n_demonstrations, 2*n_strokes*N); % each row of this matrix has all the weights for a certain demonstration

% mean trajectory before DTW with new trajectory and before ProMPs
T = 100;
mean_trajectory = cell(1,n_strokes);
for j = 1:n_strokes
    mean_trajectory{1,j} = 0*preprocessed_demonstrations{1,1}{1,j}; % Using here only the demonstrations preprocessed taking the first stroke as reference.
    for i = 1:n_demonstrations
        mean_trajectory{1,j} = mean_trajectory{1,j} + preprocessed_demonstrations{1,1}{i,j}; 
    end
    mean_trajectory{1,j} = mean_trajectory{1,j}/n_demonstrations;
end
mean_trajectory_1D = generate1DTrajectory(mean_trajectory(1,:), T);
mean_trajectory_2D = convert1Dto2D(mean_trajectory_1D, n_strokes, T); % Here the mean trajectory is represented by a matrix with n_strokes*T rows and 2 columns. This representation is useful later.

%% loop until the user does not want to learn anymore
repeat = true;
while repeat

    average_scores = NaN(1,n_strokes); % array with the average score considering each stroke as reference for alignment in space
    
    close all;
    
    %% show the user the mean trajectory
    figure(1);
    min_x = min(mean_trajectory_2D(:,1));
    max_x = max(mean_trajectory_2D(:,1));
    min_y = min(mean_trajectory_2D(:,2));
    max_y = max(mean_trajectory_2D(:,2));
    c_x = (min_x + max_x)/2;
    c_y = (min_y + max_y)/2;
    delta_x = max_x - min_x;
    delta_y = max_y - min_y;
    p = 0.1;
    if delta_x >= delta_y
        axis([c_x-delta_x/2-p*delta_x c_x+delta_x/2+p*delta_x c_y-delta_x/2-p*delta_x c_y+delta_x/2+p*delta_x]);
    else
        axis([c_x-delta_y/2-p*delta_y c_x+delta_y/2+p*delta_y c_y-delta_y/2-p*delta_y c_y+delta_y/2+p*delta_y]);
    end
    hold on;
    xlabel('x');
    ylabel('y');
    plotLineInSegments(mean_trajectory_2D, 0.00, n_strokes, T, 'b');
    
    %pause for some time to let the user view the mean trajectory
    pause(2);
    
    % Let the user try to draw the character.
    figure(2);
    hold on;
    axis(ax);
    xlabel('x');
    ylabel('y');
    hold on;
    input_trajectories = cell(1,n_strokes); % Character drawn by the user
    for i = 1:n_strokes
        h = imfreehand('Closed', false);

        % get the position (x,y coordinates) of each point of the curve
        input_trajectories{1,i} = getPosition(h);
                
    end
    
    % build a blockdiagonal matrix of the features
    feature_matrix = gaussianBasisFunction(T, N);
    block_feature_matrix = blockmatrix(feature_matrix, n_strokes*2);
    
    for reference_stroke_index = 1:n_strokes
        
        % find mean trajectory according to the reference stroke under
        % consideration
        mean_trajectory_for_ref_stroke = cell(1,n_strokes);
        for j = 1:n_strokes
            mean_trajectory_for_ref_stroke{1,j} = 0*preprocessed_demonstrations{1,reference_stroke_index}{1,j};
            for i = 1:n_demonstrations
                mean_trajectory_for_ref_stroke{1,j} = mean_trajectory_for_ref_stroke{1,j} + preprocessed_demonstrations{1,reference_stroke_index}{i,j}; 
            end
            mean_trajectory_for_ref_stroke{1,j} = mean_trajectory_for_ref_stroke{1,j}/n_demonstrations;
        end
        
        % preprocess user's trajectory
        [input_trajectories, trajectories_after_DTW_with_new_trajectory] = preprocess_trajectory( input_trajectories, mean_trajectory_for_ref_stroke, preprocessed_demonstrations{1,reference_stroke_index}, reference_stroke_index );
        
        % find weights for demonstrated trajectories
        for i = 1:n_demonstrations
            trajectory = generate1DTrajectory(trajectories_after_DTW_with_new_trajectory(i,:), T);
            w = linearRidgeRegression(trajectory,block_feature_matrix',lambda);
            weight_matrix(i,:) = w;
        end
        
        % calculate mean and covariance of the weights
        mu_weights = mean(weight_matrix);
        covariance_weights = cov(weight_matrix);
        
        %% build distribution of the trajectories
        %mean of the trajectory
        mu_trajectory = block_feature_matrix*mu_weights';
        % covariance of the trajectory
        cov_trajectory = noise*eye(length(block_feature_matrix*covariance_weights*block_feature_matrix')) + block_feature_matrix*covariance_weights*block_feature_matrix';
        % account for numerical errors and make the cov matrix symmetric again
        cov_trajectory = triu(cov_trajectory) + triu(cov_trajectory)' - diag(diag(cov_trajectory));
        %%
        
        input_trajectory_2D = convert1Dto2D(generate1DTrajectory(input_trajectories(1,:), T),n_strokes,T);
        mean_trajectory_2D_after_DTW = convert1Dto2D(mu_trajectory, n_strokes, T);
        
        %% compute probability of new trajectory
        pdfs = computePdfsOfTrajectory(input_trajectory_2D, mean_trajectory_2D_after_DTW, cov_trajectory, T, n_strokes);
        maximum_pdfs = computePdfsOfTrajectory(mean_trajectory_2D_after_DTW, mean_trajectory_2D_after_DTW, cov_trajectory, T, n_strokes);
        
        scores = computeScore(input_trajectory_2D, pdfs, maximum_pdfs, n_strokes, T);
        average_scores(1,reference_stroke_index) = mean(scores);

        input_trajectory_2D_for_each_ref_stroke{1,reference_stroke_index} = input_trajectory_2D;
        trajectories_after_DTW_with_new_trajectory_for_each_ref_stroke{1,reference_stroke_index} = trajectories_after_DTW_with_new_trajectory;
        pdfs_for_each_ref_stroke{1,reference_stroke_index} = pdfs;
        maximum_pdfs_for_each_ref_stroke{1,reference_stroke_index} = maximum_pdfs;
        mean_trajectory_2D_after_DTW_for_each_ref_stroke{1,reference_stroke_index} = mean_trajectory_2D_after_DTW;
        cov_trajectory_for_each_ref_stroke{1,reference_stroke_index} = cov_trajectory;
        
    end
    
    %% find the index of the best score and use it to select what to plot
    [M,I] = max(average_scores);
    input_trajectory_2D = input_trajectory_2D_for_each_ref_stroke{1,I};
    trajectories_after_DTW_with_new_trajectory = trajectories_after_DTW_with_new_trajectory_for_each_ref_stroke{1,I};
    pdfs = pdfs_for_each_ref_stroke{1,I};
    maximum_pdfs = maximum_pdfs_for_each_ref_stroke{1,I};
    mean_trajectory_2D_after_DTW = mean_trajectory_2D_after_DTW_for_each_ref_stroke{1,I};
    cov_trajectory = cov_trajectory_for_each_ref_stroke{1,I};
    
    %% Create Plots for the user to interpret his/her results
    % show the recorded trajectory and all the demonstrations
    figure(3);
    set_fig_position([0.479 0.428 0.136 0.234]);
    min_x = min(input_trajectory_2D(:,1));
    max_x = max(input_trajectory_2D(:,1));
    min_y = min(input_trajectory_2D(:,2));
    max_y = max(input_trajectory_2D(:,2));
    c_x = (min_x + max_x)/2;
    c_y = (min_y + max_y)/2;
    delta_x = max_x - min_x;
    delta_y = max_y - min_y;
    p = 0.11;
    if delta_x >= delta_y
        axis([c_x-delta_x/2-p*delta_x c_x+delta_x/2+p*delta_x c_y-delta_x/2-p*delta_x c_y+delta_x/2+p*delta_x]);
    else
        axis([c_x-delta_y/2-p*delta_y c_x+delta_y/2+p*delta_y c_y-delta_y/2-p*delta_y c_y+delta_y/2+p*delta_y]);
    end
    hold on;
    % plot demonstrations in light gray
    for i = 1:n_demonstrations
        for j = 1:n_strokes
            subTrajectory = trajectories_after_DTW_with_new_trajectory{i,j};
            plot(subTrajectory(:,1), subTrajectory(:,2), '-', 'Color', light_gray, 'LineWidth', 2);
        end
    end
    
    % show the probability
    figure(4);
    set_fig_position([0.421 0.436 0.167 0.3]);
    hold on;
    plot(pdfs, 'r-', 'LineWidth', 2);
    plot(maximum_pdfs, 'b-', 'LineWidth', 2);
    xlabel('time step');
    ylabel('pdf value');
    legend('pdf new trajectory', 'pdf mean');
    ylims = ylim;
    for i = 1:n_strokes-1
        plot([i*T i*T], [ylims(1) ylims(2)], '--k', 'LineWidth', 2);
    end
    
    figure(3);
    values = plotColorbasedFeedback(input_trajectory_2D, pdfs, maximum_pdfs, n_strokes, T);
    pause;
    close;
    
    % create errorbar plots
    figure(6);
    set_fig_position([0.233 0.284 0.275 0.39]);
    hold on;
    createErrorbarPlot(trajectories_after_DTW_with_new_trajectory, input_trajectory_2D, mean_trajectory_2D_after_DTW, cov_trajectory, n_demonstrations, n_strokes, T);
    
    % plot value of trajectory
    figure(7);
    set_fig_position([0.421 0.436 0.167 0.3]);
    hold on;
    plot(values, 'LineWidth', 2);
    ylims = ylim;
    for i = 1:n_strokes-1
        plot([i*T i*T], [ylims(1) ylims(2)], '--k', 'LineWidth', 2);
    end
    xlabel('time step');
    ylabel('score');
    
    %% check if user wants to continue
    request = input('if you want to try again type "y" or anything else otherwise: ','s');
    if ~strcmp(request,'y')
        repeat = false;
    end
    
end














