function trajectory_rescaled = rescale_in_space( trajectory, steps_of_reference_stroke, reference_width_or_height )
% rescale trajectory
% input and output trajectories are in format [x_stroke_1 y_stroke_1; x_stroke_2 y_stroke_2; ...]
                
    % compute delta_x (max_x - min_x) of reference stroke
    delta_x = max(trajectory(steps_of_reference_stroke,1)) - min(trajectory(steps_of_reference_stroke,1));
    % compute delta_y (max_y - min_y) of reference stroke
    delta_y = max(trajectory(steps_of_reference_stroke,2)) - min(trajectory(steps_of_reference_stroke,2));
    
    % Rescale without shift
    if delta_x >= delta_y
        trajectory_rescaled(:,1) = min(trajectory(:,1)) + (trajectory(:,1) - min(trajectory(:,1))).*(reference_width_or_height/delta_x);
        trajectory_rescaled(:,2) = min(trajectory(:,2)) + (trajectory(:,2) - min(trajectory(:,2))).*(reference_width_or_height/delta_x);
    else
        trajectory_rescaled(:,1) = min(trajectory(:,1)) + (trajectory(:,1) - min(trajectory(:,1))).*(reference_width_or_height/delta_y);
        trajectory_rescaled(:,2) = min(trajectory(:,2)) + (trajectory(:,2) - min(trajectory(:,2))).*(reference_width_or_height/delta_y);
    end
    
end

