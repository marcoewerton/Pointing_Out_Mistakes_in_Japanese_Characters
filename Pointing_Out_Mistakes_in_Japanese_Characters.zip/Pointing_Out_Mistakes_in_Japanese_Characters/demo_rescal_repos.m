% Script to create figure showing the rescaling in space and the
% repositioning of two trajectories
clear variables;
close all;
clc;

%add utility paths
addpath(genpath('mathUtility'));
addpath(genpath('plotUtility'));
addpath(genpath('utility'));
addpath(genpath('rescale_in_Space'));
addpath(genpath('rescale_in_Time'));

% define number of demonstrations
n_demonstrations = 2;

n_strokes = input('Please enter the amount of strokes you need to demonstrate: ');

n_steps_of_each_stroke_of_each_demonstration = NaN(n_demonstrations,n_strokes);

% alocate cell for trajectories 
trajectories = cell(n_demonstrations, n_strokes);

concat_trajectories = cell(n_demonstrations, 1);

% record all trajectories
for i = 1:n_demonstrations
    
    close;
    figure(i);
    axis([0 1 0 1]);
    hold on;
    
    for j = 1:n_strokes    
        
        h = imfreehand('Closed', false);
                
        % get the position (x,y coordinates) of each point of the curve
        positions = getPosition(h);
        
        trajectories{i,j} = positions;
        
        n_steps_of_each_stroke_of_each_demonstration(i,j) = size(positions,1);
        
        concat_trajectories{i,1} = [concat_trajectories{i,1}; positions];
        
    end
    
end

close;

figure(1);
set_fig_position([0.349 0.339 0.161 0.262]);
axis([0 1 0 1]);
hold on;
for i = 1:n_demonstrations
    if i == 1
        line_and_color = '-b';
    else
        line_and_color = '-r';
    end
    for j = 1:n_strokes
        plot(trajectories{i,j}(:,1), trajectories{i,j}(:,2), line_and_color, 'LineWidth', 2);
    end
end

% rescale trajectories in space
concat_trajectory1_rescaled = rescale_in_space( concat_trajectories{1,1}, n_steps_of_each_stroke_of_each_demonstration(1,1), 1 );
concat_trajectory2_rescaled = rescale_in_space( concat_trajectories{2,1}, n_steps_of_each_stroke_of_each_demonstration(2,1), 1 );
trajectory1_rescaled = cell(1,n_strokes);
trajectory2_rescaled = cell(1,n_strokes);
offset = 0;
for j = 1:n_strokes
   n = length(trajectories{1,j});
   trajectory1_rescaled{1,j} = concat_trajectory1_rescaled(offset+1:offset+n,:);
   offset = offset + n;
end
offset = 0;
for j = 1:n_strokes
   n = length(trajectories{2,j});
   trajectory2_rescaled{1,j} = concat_trajectory2_rescaled(offset+1:offset+n,:);
   offset = offset + n;
end
% plot after rescaling in space
figure(2);
axis([-0.25 2.25 0 2.5]);
set_fig_position([0.349 0.339 0.161 0.262]);
hold on;
for j = 1:n_strokes
    plot(trajectory1_rescaled{1,j}(:,1), trajectory1_rescaled{1,j}(:,2), '-b', 'LineWidth', 2);
    plot(trajectory2_rescaled{1,j}(:,1), trajectory2_rescaled{1,j}(:,2), '-r', 'LineWidth', 2);
end

% repositioning
shifted_concat_trajectory_1 = bsxfun(@minus, concat_trajectory1_rescaled, concat_trajectory1_rescaled(1,:));
shifted_concat_trajectory_2 = bsxfun(@minus, concat_trajectory2_rescaled, concat_trajectory2_rescaled(1,:));

shifted_trajectory1_rescaled = cell(1,n_strokes);
shifted_trajectory2_rescaled = cell(1,n_strokes);
offset = 0;
for j = 1:n_strokes
   n = length(trajectories{1,j});
   shifted_trajectory1_rescaled{1,j} = shifted_concat_trajectory_1(offset+1:offset+n,:);
   offset = offset + n;
end
offset = 0;
for j = 1:n_strokes
   n = length(trajectories{2,j});
   shifted_trajectory2_rescaled{1,j} = shifted_concat_trajectory_2(offset+1:offset+n,:);
   offset = offset + n;
end

% plot after repositioning
figure(3);
axis([-1 2 -2 1]);
set_fig_position([0.349 0.339 0.161 0.262]);
hold on;
for j = 1:n_strokes
    plot(shifted_trajectory1_rescaled{1,j}(:,1), shifted_trajectory1_rescaled{1,j}(:,2), '-b', 'LineWidth', 2);
    plot(shifted_trajectory2_rescaled{1,j}(:,1), shifted_trajectory2_rescaled{1,j}(:,2), '-r', 'LineWidth', 2);
end

save('workspace_after_demo_rescal_repos.mat');
