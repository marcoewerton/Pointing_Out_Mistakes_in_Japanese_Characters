% show recorded trajectories

clear variables;
close all;
clc;

% let the user select which demonstration he wants to learn
demonstration_name = input('Please Enter the name of the demonstration you want to see!: ','s');

% file_struct = load(['demonstrations/demonstration_' demonstration_name '.mat']);
file_struct = load(['preprocessed_demonstrations/preprocessed_demonstration_' demonstration_name '.mat']);
trajectories = file_struct.trajectories;
n_demonstrations = size(trajectories,1);

n_strokes = size(trajectories,2);

figure(1);
hold all;
for i = 1:n_demonstrations
   for j = 1:n_strokes
        subTrajectory = trajectories{i,j};
        plot(subTrajectory(:,1), subTrajectory(:,2), '-b', 'LineWidth', 2);
   end
end