function [ values] = computeScore( trajectory_2D, probabilities, maximum_probabilities, n_strokes, T)

    % define offsets for arctangens
    offset_x = -0.5;
    stretch_x = 15;
    offset_y = 0.5;
    stretch_y = 2;
    max_atan = atan((1+offset_x)*stretch_x);
    n_steps = T*n_strokes;
    values = zeros(n_steps,1);
    % compute values at each timestep
    for i = 1:n_steps
        value = my_scale(0,maximum_probabilities(i),probabilities(i));
        values(i) = atan((value+offset_x)*stretch_x)/(stretch_y*max_atan) + offset_y;
    end
    
end

