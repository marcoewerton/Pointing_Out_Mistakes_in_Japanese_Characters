function [ trajectory_2D ] = convert1Dto2D( trajectory_1D, n_strokes, T)
%CONVERT1DTO2D
%   takes a column vector as input with format (x y x y)' and outputs a
%   matrix with 2 columns (x y)
%                         (x y)
    trajectory_2D = [];
    for i = 1:n_strokes
        a = trajectory_1D(1+2*T*(i-1):T+2*T*(i-1),1);
        b = trajectory_1D(T+1+2*T*(i-1):2*T*i,1);
        c= [a,b];
        trajectory_2D = [trajectory_2D;c];
    end

end

