function [  trajectory ] = interpl_trajectory( trajectory, timesteps)
%INTERPL_TRAJECTORY

    original_length = size(trajectory,1);
    reference_length = timesteps;
        
    original_timeStamps = linspace(0,1,original_length);
    reference_timeStamps = linspace(0,1,reference_length);
    trajectory = interp1(original_timeStamps,  trajectory, reference_timeStamps, 'spline');

end

