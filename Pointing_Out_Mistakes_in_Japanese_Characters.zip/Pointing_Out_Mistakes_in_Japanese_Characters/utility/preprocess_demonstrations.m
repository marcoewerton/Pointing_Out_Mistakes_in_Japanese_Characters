function preprocessed_demonstrations = preprocess_demonstrations( demonstrations )

    % demonstrations is a cell <n_demonstrations X n_strokes>
    n_demonstrations = size(demonstrations,1);
    n_strokes = size(demonstrations,2);

    preprocessed_demonstrations = cell(1, n_strokes); % Each stroke will be used once as reference. The demonstrations will be preprocessed once for each reference stroke.
        
    n_steps_of_each_stroke_of_each_demonstration = NaN(n_demonstrations,n_strokes); % number of steps of each stroke of each demonstration
    steps_of_each_stroke_of_each_demonstration = cell(n_demonstrations,n_strokes);
    trajectories2D = cell(n_demonstrations,1); % demonstrations with all strokes concatenated
        
    % put all trajectories in the format [x_stroke_1 y_stroke_1; x_stroke_2 y_stroke_2; ...]
    for i = 1:n_demonstrations
        trajectory2D = [];
        start = 0;
        for j = 1:n_strokes
            n_steps_of_each_stroke_of_each_demonstration(i,j) = size(demonstrations{i,j},1);
            steps_of_each_stroke_of_each_demonstration{i,j} = start+1:start+n_steps_of_each_stroke_of_each_demonstration(i,j);
            start = start+n_steps_of_each_stroke_of_each_demonstration(i,j);
            trajectory2D = [trajectory2D; demonstrations{i,j}];
        end
        trajectories2D{i,1} = trajectory2D;
    end
    
    for reference_stroke_index = 1:n_strokes
    
        preprocessed_demonstrations{1,reference_stroke_index} = cell(n_demonstrations, n_strokes);
        
        preprocessed_trajectories2D = trajectories2D;
        
        % rescale all trajectories in space
        for i = 1:n_demonstrations
            preprocessed_trajectories2D{i,1} = rescale_in_space(trajectories2D{i,1}, steps_of_each_stroke_of_each_demonstration{i,reference_stroke_index}, 1);
        end
        
        % shift all trajectories such that the reference stroke starts at (0,0) and put them back in their original
        % representation
        for i = 1:n_demonstrations
            first_step_ref_stroke = steps_of_each_stroke_of_each_demonstration{i,reference_stroke_index}(1);
            preprocessed_trajectories2D{i,1} = bsxfun(@minus, preprocessed_trajectories2D{i,1}, preprocessed_trajectories2D{i,1}(first_step_ref_stroke,:));
            offset = 0; % variable used to represent the preprocessed demonstrations using their original cell representation
            for j = 1:n_strokes
                Tij = n_steps_of_each_stroke_of_each_demonstration(i,j);
                preprocessed_demonstrations{1,reference_stroke_index}{i,j} = preprocessed_trajectories2D{i,1}(1+offset:Tij+offset,:);
                offset = offset + Tij;
            end
        end
       
        % rescale all trajectories in time
        for i = 1:n_demonstrations-1
            for j = 1:n_strokes
                [ preprocessed_demonstrations{1,reference_stroke_index}{i,j}, preprocessed_demonstrations{1,reference_stroke_index}{i+1,j}, upDownPath, cost ] = my_dtw( preprocessed_demonstrations{1,reference_stroke_index}{i,j}, preprocessed_demonstrations{1,reference_stroke_index}{i+1,j} );
                for k = 1:i-1
                    preprocessed_demonstrations{1,reference_stroke_index}{k,j} = preprocessed_demonstrations{1,reference_stroke_index}{k,j}(upDownPath(:,1),:);
                end
            end
        end
        
    end
    
end

