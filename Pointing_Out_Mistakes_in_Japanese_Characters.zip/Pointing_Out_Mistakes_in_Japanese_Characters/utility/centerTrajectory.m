function [ centered_trajectory ] = centerTrajectory( trajectory, axis )
    max_x_trajectory = max(trajectory(:,1));
    min_x_trajectory = min(trajectory(:,1));
    max_y_trajectory = max(trajectory(:,2));
    min_y_trajectory = min(trajectory(:,2));
    
    center_x_trajectory = (max_x_trajectory + min_x_trajectory)/2;
    center_y_trajectory = (max_y_trajectory + min_y_trajectory)/2;
    
    center_x_window = (axis(2) + axis(1))/2;
    center_y_window = (axis(4) + axis(1))/2;
    
    centered_trajectory = NaN(size(trajectory,1), size(trajectory,2));  
    centered_trajectory(:,1) = trajectory(:,1) - center_x_trajectory + center_x_window;
    centered_trajectory(:,2) = trajectory(:,2) - center_y_trajectory + center_y_window;
   
end

