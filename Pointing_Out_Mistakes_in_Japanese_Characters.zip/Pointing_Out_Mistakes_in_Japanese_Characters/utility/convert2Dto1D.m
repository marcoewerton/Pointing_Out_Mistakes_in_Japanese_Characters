function [ trajectory_1D ] = convert2Dto1D( trajectory_2D, n_strokes, T )
%CONVERT2DTO1D
    trajectory_1D = [];
    for i = 1:n_strokes
        trajectory_1D = [trajectory_1D; trajectory_2D(1+T*(i-1):T*i,1); trajectory_2D(1+T*(i-1):T*i,2)];
    end

end

