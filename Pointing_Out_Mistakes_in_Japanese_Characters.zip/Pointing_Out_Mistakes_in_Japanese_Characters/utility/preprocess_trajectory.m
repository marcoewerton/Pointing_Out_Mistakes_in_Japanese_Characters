function [preprocessed_trajectory, trajectories_after_DTW_with_new_trajectory] = preprocess_trajectory( trajectory, mean_trajectory, trajectories, reference_stroke_index )

    % trajectory is a cell <1 X n_strokes>
    preprocessed_trajectory = trajectory;

    n_strokes = size(trajectory,2);

    trajectories_after_DTW_with_new_trajectory = trajectories; % the original demonstrations are also warped in time
    
    n_steps_of_each_stroke = NaN(1,n_strokes);
    steps_of_each_stroke = cell(1,n_strokes);
            
    % put trajectories in the format [x_stroke_1 y_stroke_1; x_stroke_2 y_stroke_2; ...]
    trajectory2D = [];
    start = 0;
    for j = 1:n_strokes
        n_steps_of_each_stroke(1,j) = size(trajectory{1,j},1);
        steps_of_each_stroke{1,j} = start+1:start+n_steps_of_each_stroke(1,j);
        start = start+n_steps_of_each_stroke(1,j);
        trajectory2D = [trajectory2D; trajectory{1,j}];
    end
        
    % rescale trajectory in space according to reference stroke
    preprocessed_trajectory2D = rescale_in_space(trajectory2D, steps_of_each_stroke{1,reference_stroke_index}, 1);
            
    % shift trajectory according to reference stroke
    first_step_ref_stroke = steps_of_each_stroke{1,reference_stroke_index}(1);
    preprocessed_trajectory2D = bsxfun(@minus, preprocessed_trajectory2D, preprocessed_trajectory2D(first_step_ref_stroke,:));
    offset = 0; % variable used to represent the preprocessed trajectory using its original cell representation
    for j = 1:n_strokes
        Tj = n_steps_of_each_stroke(1,j);
        preprocessed_trajectory{1,j} = preprocessed_trajectory2D(1+offset:Tj+offset,:);
        offset = offset + Tj;
    end
        
    % rescale trajectory in time
    n_demonstrations = size(trajectories,1);
    for j = 1:n_strokes
        [ mean_trajectory{1,j}, preprocessed_trajectory{1,j}, upDownPath, cost ] = my_dtw( mean_trajectory{1,j}, preprocessed_trajectory{1,j} );
        for i = 1:n_demonstrations
            trajectories_after_DTW_with_new_trajectory{i,j} = trajectories{i,j}(upDownPath(:,1),:);
        end
    end
            
end

