function [ trajectory ] = generate1DTrajectory( trajectory_array, T )
% GENERATE1DTRAJECTORY
    trajectory = [];
    n_strokes = size(trajectory_array,2);
    for i = 1:n_strokes
       int_tr = interpl_trajectory(trajectory_array{1,i},T);
       trajectory = [trajectory;[int_tr(:,1);int_tr(:,2)]];
       % format of trajectory is [x first stroke; y first stroke; x second stroke; y second stroke; ...]
    end

end

