function [ warped_X, warped_Y, upDownPath, cost ] = my_dtw( X, Y )
    
    distances = zeros(length(Y), length(X));

    for i = 1:length(Y)
        for j = 1:length(X)
            distances(i,j) = norm(Y(i,:) - X(j,:));
        end
    end
    
    accumulated_cost = zeros(length(Y), length(X));
    
    accumulated_cost(1,1) = distances(1,1);
    
    for i = 2:length(X)
        accumulated_cost(1,i) = distances(1,i) + accumulated_cost(1,i-1);
    end
    
    for i = 2:length(Y)
        accumulated_cost(i,1) = distances(i,1) + accumulated_cost(i-1,1);
    end
    
    for i = 2:length(Y)
        for j = 2:length(X)
            accumulated_cost(i,j) = min([accumulated_cost(i-1,j), accumulated_cost(i-1,j-1), accumulated_cost(i,j-1)]) + distances(i,j);
        end
    end
    
    path = [length(X), length(Y)];
    cost = distances(length(Y), length(X));
    i = length(Y);
    j = length(X);
    while i~=1 || j~=1
        if i==1
            j = j-1;
        elseif j==1
            i = i-1;
        else
            if accumulated_cost(i-1,j) == min([accumulated_cost(i-1,j), accumulated_cost(i-1,j-1), accumulated_cost(i,j-1)])
                i = i-1;
            elseif accumulated_cost(i,j-1) == min([accumulated_cost(i-1,j), accumulated_cost(i-1,j-1), accumulated_cost(i,j-1)])
                j = j-1;
            else
                i = i-1;
                j = j-1;
            end
        end
        path = [path; j, i];
        cost = cost + distances(i,j);
    end
    
    upDownPath = flipud(path);
    warped_X = X(upDownPath(:,1),:);
    warped_Y = Y(upDownPath(:,2),:);
           
end

